/*
 * SIM7672SA.c
 *
 *  Created on: Jun 22, 2024
 *      Author: jorge Luis Martines Suarez
 */
#include"SIM7672SA.h"
#include"UART.h"

void init_simcom7672sa(void){
	 Transmit("AT+CRESET\r\n");
	  HAL_Delay(26000);
	  Transmit("AT+CMQTTSTART\r\n");
	  HAL_Delay(2000);
	  Transmit("AT+CMQTTACCQ=0,\"jorge22\"\r\n");
	  HAL_Delay(2000);
	  Transmit("AT+CMQTTCONNECT=0,\"tcp://broker.hivemq.com:1883\",60,1\r\n");
	  HAL_Delay(2000);
	  Transmit("AT+CMQTTTOPIC=0,5\r\n");
	  HAL_Delay(2000);
	  Transmit("jorge\r\n");
	  HAL_Delay(2000);
	  Transmit("AT+CMQTTPAYLOAD=0,5\r\n");
	  HAL_Delay(2000);
	  Transmit("READY\r\n");
	  HAL_Delay(2000);
	  Transmit("AT+CMQTTPUB=0,1,5\r\n");
}
void enviar_data(const char* topic, const char* message) {
    char command[100];
    int topic_len = strlen(topic);
    int message_len = strlen(message);
    sprintf(command, "AT+CMQTTTOPIC=0,%d\r\n", topic_len);
    Transmit(command);
    HAL_Delay(1000);
    Transmit(topic);
    Transmit("\r\n");
    HAL_Delay(1000);
    sprintf(command, "AT+CMQTTPAYLOAD=0,%d\r\n", message_len);
    Transmit(command);
    HAL_Delay(1000);
    Transmit(message);
    Transmit("\r\n");
    HAL_Delay(1000);
    sprintf(command, "AT+CMQTTPUB=0,1,%d\r\n", message_len);
    Transmit(command);
    HAL_Delay(1000);
}

void enviar(void){
	  Transmit("AT+CMQTTTOPIC=0,5\r\n");
		  HAL_Delay(1000);
		  Transmit("jorge\r\n");
		  HAL_Delay(1000);
		  Transmit("AT+CMQTTPAYLOAD=0,1\r\n");
		  HAL_Delay(1000);
		  Transmit("1\r\n");
		  HAL_Delay(1000);
		  Transmit("AT+CMQTTPUB=0,1,1\r\n");
}
