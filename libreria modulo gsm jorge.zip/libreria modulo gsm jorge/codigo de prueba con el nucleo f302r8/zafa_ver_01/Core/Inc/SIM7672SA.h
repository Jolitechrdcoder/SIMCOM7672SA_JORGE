/*
 * SIM7672SA.c
 *
 *  Created on: Jun 22, 2024
 *      Author: jorge Luis Martines Suarez
 */

#ifndef INC_SIM7672SA_H_
#define INC_SIM7672SA_H_
#include "stm32f3xx_hal.h"
#include "string.h"
void init_simcom7672sa(void);
void enviar_data(const char* topic, const char* message);
void enviar(void);

#endif /* INC_SIM7672SA_H_ */
